package com.example.callshield

import android.app.Application

/**
 * onCreate casi vacío (arranque en frío rápido). Solo lanza la carga de reglas
 * en un hilo aparte; el servicio espera ese resultado un máximo acotado.
 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread {
            val snapshot = try {
                Snapshot.from(RulesRepository(this@App).load())
            } catch (t: Throwable) {
                Snapshot.from(Config(emptySet()))
            }
            RuleStore.publish(snapshot)
        }.apply {
            name = "rules-loader"
            priority = Thread.MAX_PRIORITY
        }.start()
    }
}
