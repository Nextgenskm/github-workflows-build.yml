package com.example.callshield

import android.content.Context
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** packages: nombres de paquete a cerrar al abrirse, p. ej. "com.whatsapp". */
data class Config(val packages: Set<String>)

object Packages {
    private val VALID = Regex("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$")

    fun canonical(input: String): String? {
        val t = input.trim().lowercase()
        return if (VALID.matches(t)) t else null
    }
}

class Snapshot private constructor(private val blocked: Set<String>) {
    fun shouldClose(pkg: String?): Boolean = pkg != null && pkg in blocked

    companion object {
        fun from(c: Config) = Snapshot(HashSet(c.packages))
    }
}

object RuleStore {
    private const val MAX_WAIT_MS = 400L

    @Volatile private var snapshot: Snapshot? = null
    private val ready = CountDownLatch(1)

    fun publish(s: Snapshot) {
        snapshot = s
        ready.countDown()
    }

    fun current(): Snapshot? {
        snapshot?.let { return it }
        ready.await(MAX_WAIT_MS, TimeUnit.MILLISECONDS)
        return snapshot
    }
}

class RulesRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("rules", Context.MODE_PRIVATE)

    fun load() = Config(prefs.getStringSet(KEY_PACKAGES, emptySet())!!.toSet())

    fun save(c: Config) {
        prefs.edit().putStringSet(KEY_PACKAGES, HashSet(c.packages)).apply()
    }

    private companion object { const val KEY_PACKAGES = "packages" }
}
