package com.example.callshield

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val io = Executors.newSingleThreadExecutor()
    private lateinit var repo: RulesRepository
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var adapter: ArrayAdapter<String>

    private var config = Config(emptySet())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repo = RulesRepository(this)
        status = findViewById(R.id.statusText)
        input = findViewById(R.id.entryInput)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        val list = findViewById<ListView>(R.id.entriesList)
        list.adapter = adapter
        list.setOnItemLongClickListener { _, _, position, _ ->
            adapter.getItem(position)?.let { update(config.copy(packages = config.packages - it)) }
            true
        }

        findViewById<Button>(R.id.roleButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.addButton).setOnClickListener { addEntry() }

        io.execute {
            val loaded = repo.load()
            runOnUiThread { config = loaded; render() }
        }
    }

    override fun onResume() {
        super.onResume()
        status.setText(if (isServiceEnabled()) R.string.status_active else R.string.status_inactive)
    }

    override fun onDestroy() {
        io.shutdown()
        super.onDestroy()
    }

    private fun isServiceEnabled(): Boolean {
        val me = ComponentName(this, AppBlockService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.equals(me, ignoreCase = true) }
    }

    private fun addEntry() {
        val pkg = Packages.canonical(input.text.toString())
        if (pkg == null) {
            Toast.makeText(this, R.string.invalid_entry, Toast.LENGTH_LONG).show()
            return
        }
        input.text.clear()
        update(config.copy(packages = config.packages + pkg))
    }

    private fun update(newConfig: Config) {
        config = newConfig
        render()
        io.execute {
            repo.save(newConfig)
            RuleStore.publish(Snapshot.from(newConfig))
        }
    }

    private fun render() {
        adapter.clear()
        adapter.addAll(config.packages.sorted())
        adapter.notifyDataSetChanged()
    }
}
