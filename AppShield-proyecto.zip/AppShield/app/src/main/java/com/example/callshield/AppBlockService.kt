package com.example.callshield

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

class AppBlockService : AccessibilityService() {

    private var lastClose = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return

        if (RuleStore.current()?.shouldClose(pkg) == true) {
            // Antirrebote: evita ráfagas de eventos de la misma apertura
            val now = SystemClock.elapsedRealtime()
            if (now - lastClose > 300) {
                lastClose = now
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
        }
    }

    override fun onInterrupt() = Unit
}
